# audio_merger

`audio_merger` is a simple Python library for merging WAV audio files.

## Installation

```bash
pip install audio_merger
